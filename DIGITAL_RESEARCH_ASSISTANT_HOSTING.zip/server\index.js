import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { fileURLToPath } from 'url';
import { dbInstance } from './db.js';
import { SEED_DATA } from './seedData.js';
import { fetchChatGPTShare } from './chatgptFetcher.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.resolve(__dirname, '../dist');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '20mb' }));

// Seed database on startup if empty
dbInstance.seedIfEmpty(SEED_DATA);

// 1. Health & Database Stats Endpoint
app.get('/api/health', (req, res) => {
  try {
    const stats = dbInstance.getStats();
    res.json({
      status: 'online',
      message: 'Digital Research Assistant Database Engine Running',
      database: 'SQLite 3 (node:sqlite)',
      engine: 'WAL Mode Active',
      timestamp: new Date().toISOString(),
      stats
    });
  } catch (err) {
    res.status(500).json({ status: 'error', error: err.message });
  }
});

// 2. Full Application State Snapshot
app.get('/api/state', (req, res) => {
  try {
    const state = dbInstance.getFullState();
    res.json(state);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Batch Sync State from Client
app.post('/api/sync', (req, res) => {
  try {
    const state = req.body;
    dbInstance.syncFullState(state);
    res.json({ success: true, message: 'State successfully persisted to SQLite database' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Projects Endpoints
app.get('/api/projects', (req, res) => {
  try {
    res.json(dbInstance.getAll('projects'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/projects', (req, res) => {
  try {
    const project = req.body;
    if (!project.id) project.id = `proj-${Date.now()}`;
    dbInstance.saveProject(project);
    res.json({ success: true, project });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/projects/:id', (req, res) => {
  try {
    const project = { ...req.body, id: req.params.id };
    dbInstance.saveProject(project);
    res.json({ success: true, project });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/projects/:id', (req, res) => {
  try {
    dbInstance.deleteItem('projects', req.params.id);
    res.json({ success: true, message: `Project ${req.params.id} deleted` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Experiments Endpoints
app.get('/api/experiments', (req, res) => {
  try {
    res.json(dbInstance.getAll('experiments'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/experiments', (req, res) => {
  try {
    const exp = req.body;
    if (!exp.id) exp.id = `exp-${Date.now()}`;
    dbInstance.saveExperiment(exp);
    res.json({ success: true, experiment: exp });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/experiments/:id', (req, res) => {
  try {
    dbInstance.deleteItem('experiments', req.params.id);
    res.json({ success: true, message: `Experiment ${req.params.id} deleted` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Lab Runs & Bioreactor Telemetry
app.get('/api/lab-runs', (req, res) => {
  try {
    res.json(dbInstance.getAll('lab_runs'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/lab-runs/:id', (req, res) => {
  try {
    const run = { ...req.body, id: req.params.id };
    dbInstance.saveLabRun(run);
    res.json({ success: true, labRun: run });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Tasks Endpoints
app.get('/api/tasks', (req, res) => {
  try {
    res.json(dbInstance.getAll('tasks'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tasks', (req, res) => {
  try {
    const task = req.body;
    if (!task.id) task.id = `task-${Date.now()}`;
    dbInstance.saveTask(task);
    res.json({ success: true, task });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/tasks/:id', (req, res) => {
  try {
    const task = { ...req.body, id: req.params.id };
    dbInstance.saveTask(task);
    res.json({ success: true, task });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Research Memory Endpoints (8 Categories)
app.get('/api/memory', (req, res) => {
  try {
    res.json(dbInstance.getAll('research_memory'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/memory', (req, res) => {
  try {
    const item = req.body;
    if (!item.id) item.id = `mem-${Date.now()}`;
    dbInstance.saveMemoryItem(item);
    res.json({ success: true, item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Decisions Endpoints
app.get('/api/decisions', (req, res) => {
  try {
    res.json(dbInstance.getAll('decisions'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/decisions', (req, res) => {
  try {
    const decision = req.body;
    if (!decision.id) decision.id = `dec-${Date.now()}`;
    dbInstance.saveDecision(decision);
    res.json({ success: true, decision });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 10. Research Questions Endpoints
app.get('/api/questions', (req, res) => {
  try {
    res.json(dbInstance.getAll('research_questions'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/questions', (req, res) => {
  try {
    const rq = req.body;
    if (!rq.id) rq.id = `rq-${Date.now()}`;
    dbInstance.saveResearchQuestion(rq);
    res.json({ success: true, question: rq });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/questions/:id', (req, res) => {
  try {
    const rq = { ...req.body, id: req.params.id };
    dbInstance.saveResearchQuestion(rq);
    res.json({ success: true, question: rq });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/questions/:id', (req, res) => {
  try {
    dbInstance.deleteItem('research_questions', req.params.id);
    res.json({ success: true, message: `Question ${req.params.id} deleted` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 10b. Imported AI Sources & Shared ChatGPT Discussions Endpoints
app.get('/api/sources', (req, res) => {
  try {
    res.json(dbInstance.getAll('imported_sources'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/sources', (req, res) => {
  try {
    const src = req.body;
    if (!src.id) src.id = `imp-${Date.now()}`;
    dbInstance.saveImportedSource(src);
    res.json({ success: true, source: src });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/sources/:id', (req, res) => {
  try {
    dbInstance.deleteItem('imported_sources', req.params.id);
    res.json({ success: true, message: `Source ${req.params.id} deleted` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 10c. Auto-Fetch Shared ChatGPT Conversation from URL
app.post('/api/sources/fetch-chatgpt', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'URL ChatGPT wajib diisi' });
    const result = await fetchChatGPTShare(url);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Helper: Get active IPv4 addresses across network interfaces
function getNetworkAddresses(port) {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name] || []) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({
          name,
          ip: iface.address,
          url: `http://${iface.address}:${port}`
        });
      }
    }
  }
  return addresses;
}

// 10d. Online Network Status & LAN IP Info
let currentServerPort = 3001;
app.get('/api/network-info', (req, res) => {
  const addresses = getNetworkAddresses(currentServerPort);
  res.json({
    status: 'online',
    port: currentServerPort,
    hostname: os.hostname(),
    localUrl: `http://localhost:${currentServerPort}`,
    lanUrls: addresses.map(a => a.url),
    allAddresses: addresses,
    message: 'Digital Research Assistant aktif online di jaringan lokal & siap diakses dari perangkat lain.'
  });
});

// 10e. In-App Web Viewer Proxy (bisa mengakses link yang disematkan langsung di aplikasi)
app.get('/api/proxy-web', async (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl || typeof targetUrl !== 'string') {
    return res.status(400).send('URL query parameter diperlukan');
  }
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);
    const resp = await fetch(targetUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
      }
    });
    clearTimeout(timeout);
    let html = await resp.text();
    try {
      const baseUrl = new URL(targetUrl).origin;
      if (!html.includes('<base ')) {
        html = html.replace('<head>', `<head><base href="${baseUrl}/">`);
      }
    } catch {}

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.removeHeader('X-Frame-Options');
    res.removeHeader('Content-Security-Policy');
    res.send(html);
  } catch (err) {
    res.status(500).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #f9fafb; color: #111827; }
            .card { background: white; border: 1px solid #e5e7eb; border-radius: 16px; padding: 32px; max-width: 520px; text-align: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
            .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #10a37f; color: white; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 14px; margin-top: 16px; }
            .btn:hover { background: #0d8a6b; }
          </style>
        </head>
        <body>
          <div class="card">
            <h3 style="margin-top:0;">🌐 Akses Langsung Halaman Web</h3>
            <p style="color:#6b7280;font-size:14px;line-height:1.5;">Halaman ini membatasi pratinjau di dalam frame. Anda dapat langsung membuka tautan asli di tab baru:</p>
            <a href="${targetUrl}" target="_blank" rel="noopener noreferrer" class="btn">
              Buka Tautan Asli di Tab Baru &rarr;
            </a>
          </div>
        </body>
      </html>
    `);
  }
});

// 11. Settings & Profile Endpoints
app.get('/api/settings/:key', (req, res) => {
  try {
    const value = dbInstance.getSetting(req.params.key);
    res.json({ key: req.params.key, value });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/settings/:key', (req, res) => {
  try {
    dbInstance.saveSetting(req.params.key, req.body);
    res.json({ success: true, key: req.params.key });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 12. ThingsBoard Backend Proxy & Ping Check
// Avoids CORS errors when accessing remote ThingsBoard from browser
app.post('/api/thingsboard/test-connection', async (req, res) => {
  const { serverUrl, deviceToken } = req.body;
  if (!serverUrl || !deviceToken) {
    return res.status(400).json({ success: false, message: 'serverUrl and deviceToken are required' });
  }

  const startTime = Date.now();
  const cleanUrl = serverUrl.replace(/\/+$/, '');
  const targetEndpoint = `${cleanUrl}/api/v1/${deviceToken}/attributes`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(targetEndpoint, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal
    });
    clearTimeout(timeout);
    const latency = Date.now() - startTime;

    if (response.ok || response.status === 200 || response.status === 204) {
      res.json({
        success: true,
        status: 'online',
        latency,
        statusCode: response.status,
        message: `Terhubung langsung ke ThingsBoard (${cleanUrl}). Status HTTP ${response.status} OK.`
      });
    } else {
      res.json({
        success: true, // Still reachable server
        status: 'reachable',
        latency,
        statusCode: response.status,
        message: `Server ThingsBoard merespon (${cleanUrl}), status HTTP ${response.status}. Token terverifikasi.`
      });
    }
  } catch (fetchErr) {
    // If external network is unreachable or blocked, return detailed status
    const latency = Date.now() - startTime;
    res.json({
      success: false,
      status: 'unreachable',
      latency,
      message: `Gagal menghubungi ${cleanUrl}: ${fetchErr.message}. Pastikan URL online aktif dan dapat diakses.`
    });
  }
});

// 13. ThingsBoard Telemetry Ingestion / Proxy
app.post('/api/thingsboard/telemetry', (req, res) => {
  try {
    const { deviceId, token, telemetry } = req.body;
    dbInstance.logThingsboardTelemetry({
      deviceId,
      token,
      temperature: telemetry?.temperature,
      doPercent: telemetry?.do_percent || telemetry?.do,
      od600: telemetry?.od600,
      ph: telemetry?.ph,
      rpm: telemetry?.agitator_rpm || telemetry?.rpm,
      rawPayload: telemetry
    });
    res.json({ success: true, message: 'Telemetry logged to SQLite tb_telemetry_logs' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 14. Reset Database to Default Demo
app.post('/api/reset', (req, res) => {
  try {
    dbInstance.syncFullState(SEED_DATA);
    res.json({ success: true, message: 'Database reset to default bioprocess research dataset' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 15. Serve frontend static assets in standalone/production mode
const indexPath = path.resolve(distPath, 'index.html');
if (fs.existsSync(distPath) && fs.existsSync(indexPath)) {
  console.log(`📦 Serving frontend static assets from: ${distPath}`);
  const indexHtml = fs.readFileSync(indexPath, 'utf-8');
  app.use(express.static(distPath));
  app.use((req, res, next) => {
    if ((req.method === 'GET' || req.method === 'HEAD') && !req.path.startsWith('/api')) {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.send(indexHtml);
    }
    next();
  });
}

// Start Express Server with automatic port fallback
function startServer(portToTry, maxAttempts = 10) {
  const server = app.listen(portToTry, '0.0.0.0', () => {
    const addr = server.address();
    const actualPort = (addr && typeof addr === 'object' && addr.port) ? addr.port : portToTry;
    currentServerPort = actualPort;
    const lanAddrs = getNetworkAddresses(actualPort);
    console.log(`================================================================`);
    console.log(`🚀 DIGITAL RESEARCH ASSISTANT AKTIF ONLINE & SIAP DIGUNAKAN!`);
    console.log(`🌐 Akses Lokal (PC ini): http://localhost:${actualPort}`);
    if (lanAddrs.length > 0) {
      lanAddrs.forEach(a => {
        console.log(`📱 Akses Online (HP/Lab/WiFi [${a.name}]): ${a.url}`);
      });
    } else {
      console.log(`🌐 Akses dari HP/Lab: http://<IP_KOMPUTER>:${actualPort}`);
    }
    console.log(`📁 File Database   : ${dbInstance.dbPath}`);
    console.log(`================================================================`);
    
    try {
      fs.writeFileSync(path.resolve(__dirname, '../.server_port'), String(actualPort));
    } catch (_) {}
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`⚠️ Port ${portToTry} sedang digunakan. Mencoba port ${portToTry + 1}...`);
      if (maxAttempts > 0) {
        startServer(portToTry + 1, maxAttempts - 1);
      } else {
        console.error(`❌ Gagal menemukan port kosong.`);
        process.exit(1);
      }
    } else {
      console.error(`❌ Server error:`, err);
      process.exit(1);
    }
  });
}

startServer(Number(PORT));
