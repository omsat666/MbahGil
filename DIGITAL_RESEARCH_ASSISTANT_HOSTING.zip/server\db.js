import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database file path: database.sqlite in root project directory
const DB_PATH = path.resolve(__dirname, '../database.sqlite');

export class ResearchDatabase {
  constructor(dbPath = DB_PATH) {
    this.dbPath = dbPath;
    this.db = new DatabaseSync(dbPath);
    this.initSchema();
  }

  initSchema() {
    // Enable WAL mode for high performance concurrency
    this.db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA foreign_keys = ON;

      -- Core Projects Table
      CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        category TEXT,
        status TEXT NOT NULL,
        priority TEXT,
        lead TEXT,
        progress INTEGER DEFAULT 0,
        budget TEXT,
        targetDate TEXT,
        startDate TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Experiments Table
      CREATE TABLE IF NOT EXISTS experiments (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        projectId TEXT,
        status TEXT NOT NULL,
        hypothesis TEXT,
        control TEXT,
        treatment TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Lab Runs & Bioreactor Telemetry
      CREATE TABLE IF NOT EXISTS lab_runs (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        equipmentId TEXT NOT NULL,
        equipmentName TEXT NOT NULL,
        status TEXT NOT NULL,
        statusReason TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Equipment Table
      CREATE TABLE IF NOT EXISTS equipment (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        status TEXT NOT NULL,
        location TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Operational & Research Tasks
      CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        projectId TEXT,
        assignee TEXT,
        status TEXT NOT NULL,
        priority TEXT NOT NULL,
        dueDate TEXT,
        dueTime TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Institutional Research Memory (8 Categories)
      CREATE TABLE IF NOT EXISTS research_memory (
        id TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        date TEXT NOT NULL,
        projectId TEXT,
        confidence TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Decision Log
      CREATE TABLE IF NOT EXISTS decisions (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        decision TEXT NOT NULL,
        rationale TEXT,
        status TEXT NOT NULL,
        date TEXT NOT NULL,
        projectId TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Research Questions
      CREATE TABLE IF NOT EXISTS research_questions (
        id TEXT PRIMARY KEY,
        question TEXT NOT NULL,
        hypothesis TEXT,
        status TEXT NOT NULL,
        priority TEXT,
        projectId TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Knowledge Documents
      CREATE TABLE IF NOT EXISTS knowledge_docs (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category TEXT,
        author TEXT,
        date TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Imported AI Sources & Shared ChatGPT Discussions
      CREATE TABLE IF NOT EXISTS imported_sources (
        id TEXT PRIMARY KEY,
        platform TEXT NOT NULL,
        title TEXT NOT NULL,
        author TEXT,
        projectId TEXT,
        date TEXT,
        share_url TEXT,
        data_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- Conversation Sessions & Chat History
      CREATE TABLE IF NOT EXISTS conversations (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        projectId TEXT,
        updated_at TEXT NOT NULL,
        messages_json TEXT NOT NULL
      );

      -- System Settings (User Profile, ThingsBoard Tokens, Brain Parameters)
      CREATE TABLE IF NOT EXISTS system_settings (
        key TEXT PRIMARY KEY,
        value_json TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- ThingsBoard Live Telemetry Log
      CREATE TABLE IF NOT EXISTS tb_telemetry_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT NOT NULL,
        token TEXT NOT NULL,
        temperature REAL,
        do_percent REAL,
        od600 REAL,
        ph REAL,
        rpm REAL,
        raw_payload TEXT,
        recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- System Audit Log
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        entity TEXT NOT NULL,
        entity_id TEXT,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);
  }

  // Count total records in database
  getStats() {
    const tables = [
      'projects',
      'experiments',
      'lab_runs',
      'equipment',
      'tasks',
      'research_memory',
      'decisions',
      'research_questions',
      'knowledge_docs',
      'conversations',
      'imported_sources',
      'tb_telemetry_logs'
    ];
    const stats = {};
    let total = 0;
    for (const table of tables) {
      const row = this.db.prepare(`SELECT COUNT(*) as count FROM ${table}`).get();
      stats[table] = row.count;
      total += row.count;
    }
    stats.total = total;
    stats.dbPath = this.dbPath;
    stats.dbSizeKb = fs.existsSync(this.dbPath) ? Math.round(fs.statSync(this.dbPath).size / 1024) : 0;
    return stats;
  }

  // Generic getter
  getAll(table) {
    const rows = this.db.prepare(`SELECT * FROM ${table} ORDER BY updated_at DESC`).all();
    return rows.map(r => (r.data_json ? JSON.parse(r.data_json) : r));
  }

  // Generic get by ID
  getById(table, id) {
    const row = this.db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
    if (!row) return null;
    return row.data_json ? JSON.parse(row.data_json) : row;
  }

  // Generic delete by ID
  deleteItem(table, id) {
    const validTables = [
      'projects', 'experiments', 'lab_runs', 'equipment',
      'tasks', 'research_memory', 'decisions', 'research_questions',
      'knowledge_docs', 'conversations', 'imported_sources'
    ];
    if (!validTables.includes(table)) throw new Error(`Invalid table name: ${table}`);
    this.db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
  }

  // Save or replace a project
  saveProject(project) {
    const stmt = this.db.prepare(`
      INSERT INTO projects (id, code, name, category, status, priority, lead, progress, budget, targetDate, startDate, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        code = excluded.code,
        name = excluded.name,
        category = excluded.category,
        status = excluded.status,
        priority = excluded.priority,
        lead = excluded.lead,
        progress = excluded.progress,
        budget = excluded.budget,
        targetDate = excluded.targetDate,
        startDate = excluded.startDate,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      project.id,
      project.code,
      project.name,
      project.category || '',
      project.status,
      project.priority || '',
      project.lead || '',
      project.progress || 0,
      project.budget || '',
      project.targetDate || '',
      project.startDate || '',
      JSON.stringify(project)
    );
  }

  // Save or replace an experiment
  saveExperiment(exp) {
    const stmt = this.db.prepare(`
      INSERT INTO experiments (id, code, name, projectId, status, hypothesis, control, treatment, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        code = excluded.code,
        name = excluded.name,
        projectId = excluded.projectId,
        status = excluded.status,
        hypothesis = excluded.hypothesis,
        control = excluded.control,
        treatment = excluded.treatment,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      exp.id,
      exp.code,
      exp.name,
      exp.projectId || '',
      exp.status,
      exp.hypothesis || '',
      exp.control || '',
      exp.treatment || '',
      JSON.stringify(exp)
    );
  }

  // Save or replace a task
  saveTask(task) {
    const stmt = this.db.prepare(`
      INSERT INTO tasks (id, name, projectId, assignee, status, priority, dueDate, dueTime, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        projectId = excluded.projectId,
        assignee = excluded.assignee,
        status = excluded.status,
        priority = excluded.priority,
        dueDate = excluded.dueDate,
        dueTime = excluded.dueTime,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      task.id,
      task.name,
      task.projectId || '',
      task.assignee || '',
      task.status,
      task.priority,
      task.dueDate || '',
      task.dueTime || '',
      JSON.stringify(task)
    );
  }

  // Save or replace a lab run
  saveLabRun(run) {
    const stmt = this.db.prepare(`
      INSERT INTO lab_runs (id, code, equipmentId, equipmentName, status, statusReason, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        code = excluded.code,
        equipmentId = excluded.equipmentId,
        equipmentName = excluded.equipmentName,
        status = excluded.status,
        statusReason = excluded.statusReason,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      run.id,
      run.code,
      run.equipmentId,
      run.equipmentName,
      run.status,
      run.statusReason || '',
      JSON.stringify(run)
    );
  }

  // Save or replace research memory
  saveMemoryItem(mem) {
    const stmt = this.db.prepare(`
      INSERT INTO research_memory (id, category, title, content, date, projectId, confidence, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        category = excluded.category,
        title = excluded.title,
        content = excluded.content,
        date = excluded.date,
        projectId = excluded.projectId,
        confidence = excluded.confidence,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      mem.id,
      mem.category,
      mem.title,
      mem.content,
      mem.date,
      mem.projectId || '',
      mem.confidence || '',
      JSON.stringify(mem)
    );
  }

  // Save or replace decision
  saveDecision(dec) {
    const stmt = this.db.prepare(`
      INSERT INTO decisions (id, code, decision, rationale, status, date, projectId, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        code = excluded.code,
        decision = excluded.decision,
        rationale = excluded.rationale,
        status = excluded.status,
        date = excluded.date,
        projectId = excluded.projectId,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      dec.id,
      dec.code,
      dec.decision,
      dec.rationale || '',
      dec.status,
      dec.date,
      dec.projectId || '',
      JSON.stringify(dec)
    );
  }

  // Save or replace research question
  saveResearchQuestion(rq) {
    const stmt = this.db.prepare(`
      INSERT INTO research_questions (id, question, hypothesis, status, priority, projectId, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        question = excluded.question,
        hypothesis = excluded.hypothesis,
        status = excluded.status,
        priority = excluded.priority,
        projectId = excluded.projectId,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      rq.id,
      rq.question,
      rq.hypothesis || '',
      rq.status,
      rq.priority || '',
      rq.projectId || '',
      JSON.stringify(rq)
    );
  }

  // Save or replace equipment
  saveEquipment(eq) {
    const stmt = this.db.prepare(`
      INSERT INTO equipment (id, code, name, type, status, location, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        code = excluded.code,
        name = excluded.name,
        type = excluded.type,
        status = excluded.status,
        location = excluded.location,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      eq.id,
      eq.code,
      eq.name,
      eq.type,
      eq.status,
      eq.location || '',
      JSON.stringify(eq)
    );
  }

  // Save or replace knowledge doc
  saveKnowledgeDoc(doc) {
    const stmt = this.db.prepare(`
      INSERT INTO knowledge_docs (id, title, category, author, date, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        title = excluded.title,
        category = excluded.category,
        author = excluded.author,
        date = excluded.date,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      doc.id,
      doc.title,
      doc.category || '',
      doc.author || '',
      doc.date || '',
      JSON.stringify(doc)
    );
  }

  // Save or replace imported source (Shared ChatGPT discussion)
  saveImportedSource(src) {
    const stmt = this.db.prepare(`
      INSERT INTO imported_sources (id, platform, title, author, projectId, date, share_url, data_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET
        platform = excluded.platform,
        title = excluded.title,
        author = excluded.author,
        projectId = excluded.projectId,
        date = excluded.date,
        share_url = excluded.share_url,
        data_json = excluded.data_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(
      src.id,
      src.platform,
      src.title,
      src.author || 'Researcher',
      src.projectId || '',
      src.date || new Date().toISOString().split('T')[0],
      src.shareUrl || '',
      JSON.stringify(src)
    );
  }

  // Save or replace conversation session
  saveConversation(conv) {
    const stmt = this.db.prepare(`
      INSERT INTO conversations (id, title, projectId, updated_at, messages_json)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        title = excluded.title,
        projectId = excluded.projectId,
        updated_at = excluded.updated_at,
        messages_json = excluded.messages_json
    `);
    stmt.run(
      conv.id,
      conv.title,
      conv.projectId || '',
      conv.updatedAt || new Date().toISOString(),
      JSON.stringify(conv.messages || [])
    );
  }

  // Settings getter & setter
  getSetting(key) {
    const row = this.db.prepare(`SELECT value_json FROM system_settings WHERE key = ?`).get(key);
    return row ? JSON.parse(row.value_json) : null;
  }

  saveSetting(key, value) {
    const stmt = this.db.prepare(`
      INSERT INTO system_settings (key, value_json, updated_at)
      VALUES (?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(key) DO UPDATE SET
        value_json = excluded.value_json,
        updated_at = CURRENT_TIMESTAMP
    `);
    stmt.run(key, JSON.stringify(value));
  }

  // Log ThingsBoard live telemetry
  logThingsboardTelemetry(entry) {
    const stmt = this.db.prepare(`
      INSERT INTO tb_telemetry_logs (device_id, token, temperature, do_percent, od600, ph, rpm, raw_payload)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      entry.deviceId || 'unknown',
      entry.token || '',
      entry.temperature ?? null,
      entry.doPercent ?? null,
      entry.od600 ?? null,
      entry.ph ?? null,
      entry.rpm ?? null,
      JSON.stringify(entry.rawPayload || {})
    );
  }

  // Get full application state snapshot
  getFullState() {
    return {
      projects: this.getAll('projects'),
      experiments: this.getAll('experiments'),
      labRuns: this.getAll('lab_runs'),
      equipment: this.getAll('equipment'),
      tasks: this.getAll('tasks'),
      researchMemory: this.getAll('research_memory'),
      decisions: this.getAll('decisions'),
      researchQuestions: this.getAll('research_questions'),
      knowledgeDocs: this.getAll('knowledge_docs'),
      importedSources: this.getAll('imported_sources'),
      conversations: this.db.prepare(`SELECT * FROM conversations ORDER BY updated_at DESC`).all().map(r => ({
        id: r.id,
        title: r.title,
        projectId: r.projectId,
        updatedAt: r.updated_at,
        messages: JSON.parse(r.messages_json || '[]')
      })),
      userProfile: this.getSetting('user_profile'),
      labSettings: this.getSetting('lab_settings'),
      brainSettings: this.getSetting('brain_settings'),
      characters: this.getSetting('characters'),
      selectedCharacterId: this.getSetting('selected_character_id') || 'aria'
    };
  }

  // Batch sync entire state from client
  syncFullState(state) {
    if (state.projects && Array.isArray(state.projects)) {
      for (const p of state.projects) this.saveProject(p);
    }
    if (state.experiments && Array.isArray(state.experiments)) {
      for (const e of state.experiments) this.saveExperiment(e);
    }
    if (state.labRuns && Array.isArray(state.labRuns)) {
      for (const r of state.labRuns) this.saveLabRun(r);
    }
    if (state.equipment && Array.isArray(state.equipment)) {
      for (const eq of state.equipment) this.saveEquipment(eq);
    }
    if (state.tasks && Array.isArray(state.tasks)) {
      for (const t of state.tasks) this.saveTask(t);
    }
    if (state.knowledgeDocs && Array.isArray(state.knowledgeDocs)) {
      for (const doc of state.knowledgeDocs) this.saveKnowledgeDoc(doc);
    }
    if (state.importedSources && Array.isArray(state.importedSources)) {
      for (const s of state.importedSources) this.saveImportedSource(s);
    }
    if (state.researchMemory && Array.isArray(state.researchMemory)) {
      for (const m of state.researchMemory) this.saveMemoryItem(m);
    }
    if (state.decisions && Array.isArray(state.decisions)) {
      for (const d of state.decisions) this.saveDecision(d);
    }
    if (state.researchQuestions && Array.isArray(state.researchQuestions)) {
      for (const q of state.researchQuestions) this.saveResearchQuestion(q);
    }
    if (state.conversations && Array.isArray(state.conversations)) {
      for (const c of state.conversations) this.saveConversation(c);
    }
    if (state.userProfile) {
      this.saveSetting('user_profile', state.userProfile);
    }
    if (state.labSettings) {
      this.saveSetting('lab_settings', state.labSettings);
    }
    if (state.brainSettings) {
      this.saveSetting('brain_settings', state.brainSettings);
    }
    if (state.characters) {
      this.saveSetting('characters', state.characters);
    }
    if (state.selectedCharacterId) {
      this.saveSetting('selected_character_id', state.selectedCharacterId);
    }
  }

  // Seed default dataset if database is empty
  seedIfEmpty(seedData) {
    const projectCount = this.db.prepare(`SELECT COUNT(*) as count FROM projects`).get().count;
    if (projectCount === 0) {
      console.log('🌱 Database is empty. Seeding initial bioprocess research dataset...');
      this.syncFullState(seedData);
      console.log('✅ SQLite database initialized and seeded successfully.');
    } else {
      // Check if imported_sources is empty and seed if needed
      try {
        const sourcesCount = this.db.prepare(`SELECT COUNT(*) as count FROM imported_sources`).get().count;
        if (sourcesCount === 0 && seedData.importedSources && seedData.importedSources.length > 0) {
          console.log('🌱 Seeding initial imported ChatGPT discussion sources...');
          for (const s of seedData.importedSources) {
            this.saveImportedSource(s);
          }
          console.log(`✅ Seeded ${seedData.importedSources.length} imported ChatGPT discussion sources.`);
        }
      } catch (err) {
        console.warn('Could not seed imported_sources:', err.message);
      }
    }
  }
}

// Singleton database instance
export const dbInstance = new ResearchDatabase();
