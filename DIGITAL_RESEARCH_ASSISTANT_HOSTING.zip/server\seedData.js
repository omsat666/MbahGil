// Initial Seed Data for SQLite Database
export const SEED_DATA = {
  projects: [
    {
      id: 'proj-1',
      code: 'PRJ-BD-01',
      name: 'BlueDragon Upgrade',
      category: 'Fermentation Acceleration',
      status: 'active',
      priority: 'P1 - High',
      lead: 'Dr. Ragil Prasetyo',
      progress: 68,
      budget: 'Rp 450.000.000',
      targetDate: '2026-12-15',
      startDate: '2026-06-01',
      objective: 'Optimize Bacillus fermentation kinetics, accelerate growth, reduce batch cycle from 36h to 24h with OD600 > 1.20.',
      milestones: [
        { id: 'm1', code: 'M1', name: 'Literature & baseline review', targetDate: '2026-06-30', status: 'completed', progress: 100 },
        { id: 'm2', code: 'M2', name: 'Media optimization (C:N ratio test)', targetDate: '2026-08-15', status: 'completed', progress: 100 },
        { id: 'm3', code: 'M3', name: 'Fermentation optimization & aeration control', targetDate: '2026-10-15', status: 'in_progress', progress: 75 },
        { id: 'm4', code: 'M4', name: 'Laboratory validation (100 L pilot)', targetDate: '2026-11-05', status: 'pending', progress: 20 },
        { id: 'm5', code: 'M5', name: 'Scale-up trial (500 L bioreactor)', targetDate: '2026-11-25', status: 'pending', progress: 0 },
        { id: 'm6', code: 'M6', name: 'Field validation & agronomic efficacy', targetDate: '2026-12-05', status: 'pending', progress: 0 },
        { id: 'm7', code: 'M7', name: 'Final formulation & commercial SOP', targetDate: '2026-12-15', status: 'pending', progress: 0 }
      ]
    },
    {
      id: 'proj-2',
      code: 'PRJ-MB-02',
      name: 'Microbial Strain Bank',
      category: 'Strain Library & Preservation',
      status: 'active',
      priority: 'P2 - Medium',
      lead: 'Dr. Ragil Prasetyo',
      progress: 82,
      budget: 'Rp 180.000.000',
      targetDate: '2026-11-30',
      startDate: '2026-04-10',
      objective: 'Isolate, sequence, and cryo-preserve 120 indigenous PGPR strains with enzyme-secreting capabilities.'
    },
    {
      id: 'proj-3',
      code: 'PRJ-EH-03',
      name: 'Enzymatic Hydrolysis',
      category: 'Biomass Valorization',
      status: 'active',
      priority: 'P1 - High',
      lead: 'Dr. Ragil Prasetyo',
      progress: 45,
      budget: 'Rp 320.000.000',
      targetDate: '2027-01-20',
      startDate: '2026-08-01',
      objective: 'Convert local agricultural waste into soluble oligosaccharides via cellulase-hemicellulase enzymatic cascade.'
    },
    {
      id: 'proj-4',
      code: 'PRJ-BS-04',
      name: 'Bio Shield Formulation',
      category: 'Bio-Protection',
      status: 'active',
      priority: 'P2 - Medium',
      lead: 'Budi Santoso',
      progress: 55,
      budget: 'Rp 210.000.000',
      targetDate: '2026-12-30',
      startDate: '2026-07-01',
      objective: 'Develop shelf-stable microencapsulated Trichoderma spores for foliar spray.'
    },
    {
      id: 'proj-5',
      code: 'PRJ-DP-05',
      name: 'Demoplot Field Validation',
      category: 'Field Agronomy',
      status: 'active',
      priority: 'P3 - Low',
      lead: 'Ahmad Fadli',
      progress: 30,
      budget: 'Rp 150.000.000',
      targetDate: '2027-03-01',
      startDate: '2026-09-01',
      objective: 'Multi-location trial across 5 hectares of rice paddies in West Java.'
    }
  ],
  experiments: [
    {
      id: 'exp-023',
      code: 'EXP-BD-023',
      name: 'Media Optimization vs Aeration Cascade (A/B Test)',
      projectId: 'proj-1',
      projectName: 'BlueDragon Upgrade',
      status: 'running',
      startDate: '2026-10-04',
      endDate: '2026-10-08',
      researchQuestion: 'Does amino nitrogen supplementation or higher dissolved oxygen cascade contribute more significantly to shortening Bacillus lag phase?',
      objective: 'Quantify relative growth acceleration impact of 0.8% yeast peptone medium vs 1.5 vvm dissolved oxygen cascade.',
      hypothesis: 'Media optimization provides 65% of the growth acceleration benefit because carbon-nitrogen availability is the primary metabolic rate-limiting factor.',
      control: 'Current standard fermentation protocol (SOP-FERM-001 v2.1, 1.0 vvm, basic medium).',
      treatmentA: 'Optimized nitrogen-rich medium (0.8% peptone + 0.4% yeast extract, 1.0 vvm).',
      treatmentB: 'Optimized aeration cascade (1.5 vvm, dissolved oxygen cascade >35%, basic medium).',
      measurements: ['OD600', 'pH', 'DO%', 'Temperature', 'CFU/ml', 'Batch time to OD 1.0'],
      expectedOutcome: 'Determine definitive parameter hierarchy to avoid unnecessary compressor energy costs during 500 L scale-up.',
      currentReadings: { od600: 1.14, tempC: 37.2, ph: 6.8, doPercent: 42.5 }
    },
    {
      id: 'exp-022',
      code: 'EXP-MB-022',
      name: 'Bacillus Subtilis Cryo-Viability at -80°C with 15% Glycerol',
      projectId: 'proj-2',
      projectName: 'Microbial Strain Bank',
      status: 'completed',
      startDate: '2026-09-20',
      endDate: '2026-10-02',
      researchQuestion: 'What is the 30-day viability recovery percentage of master seed strain BD-018 in 15% glycerol cryo-vials?',
      objective: 'Ensure master seed lot compliance and post-thaw recovery rate >95%.',
      hypothesis: '15% glycerol buffered with 0.1M phosphate maintains viability >95% without osmotic shock.',
      control: '10% DMSO preservation.',
      treatmentA: '15% glycerol in PBS buffer.',
      treatmentB: '20% glycerol in nutrient broth.',
      measurements: ['CFU/ml post-thaw', 'Lag phase duration (hours)', 'Colony morphology stability'],
      conclusion: '15% glycerol achieved 98.4% viability recovery and zero morphology drift. Adopted into SOP-CRYO-004.'
    }
  ],
  labRuns: [
    {
      id: 'run-01',
      code: 'RUN-2026-019',
      equipmentId: 'eq-01',
      equipmentName: 'Fermenter 01 (100 L Seed Vessel)',
      microorganism: 'Bacillus subtilis strain BD-018',
      protocol: 'SOP-FERM-001 v2.2 (Accelerated Seed)',
      medium: 'Modified Yeast Extract Peptone (MYEP-2)',
      volumeLiters: 100,
      startTime: '2026-10-05 20:00',
      expectedCompletion: '2026-10-06 18:00',
      status: 'running',
      statusReason: 'Normal growth curve on track',
      dataSource: 'ThingsBoard IoT Online / Real-time',
      currentReadings: {
        tempC: 37.2,
        ph: 6.8,
        od600: 1.14,
        doPercent: 42.5,
        aerationVvm: 1.2,
        agitationRpm: 250
      },
      timelineMilestones: [
        { hour: 0, label: 'Inoculation (0.5% v/v master seed)', completed: true, timestamp: '20:00' },
        { hour: 4, label: 'Early exponential checkpoint (OD600 > 0.25)', completed: true, timestamp: '00:00' },
        { hour: 10, label: 'Mid-log measurement (OD600 > 0.80)', completed: true, timestamp: '06:00' },
        { hour: 14, label: 'Current OD checkpoint (OD600: 1.14)', completed: true, timestamp: '10:00' },
        { hour: 18, label: 'Target Harvest & 250 L Scale-up (OD600 > 1.25)', completed: false }
      ],
      historyReadings: [
        { hour: 0, time: '20:00', tempC: 37.0, ph: 7.0, od600: 0.08, doPercent: 95.0 },
        { hour: 4, time: '00:00', tempC: 37.1, ph: 6.9, od600: 0.28, doPercent: 78.0 },
        { hour: 8, time: '04:00', tempC: 37.2, ph: 6.8, od600: 0.65, doPercent: 55.0 },
        { hour: 12, time: '08:00', tempC: 37.2, ph: 6.8, od600: 0.98, doPercent: 44.0 },
        { hour: 14, time: '10:00', tempC: 37.2, ph: 6.8, od600: 1.14, doPercent: 42.5 }
      ]
    },
    {
      id: 'run-02',
      code: 'RUN-2026-020',
      equipmentId: 'eq-02',
      equipmentName: 'Fermenter 02 (100 L Production Vessel)',
      microorganism: 'Bacillus amyloliquefaciens BA-04',
      protocol: 'SOP-FERM-003 v1.0',
      medium: 'Standard Molasses Urea Broth',
      volumeLiters: 100,
      startTime: '2026-10-06 02:00',
      expectedCompletion: '2026-10-07 08:00',
      status: 'attention',
      statusReason: 'Chiller valve sluggish: temperature climbed to 34.2°C (setpoint 32.0°C)',
      dataSource: 'ThingsBoard IoT Online / Real-time',
      currentReadings: {
        tempC: 34.2,
        ph: 6.4,
        od600: 0.95,
        doPercent: 28.0,
        aerationVvm: 1.0,
        agitationRpm: 300
      },
      timelineMilestones: [
        { hour: 0, label: 'Inoculation', completed: true },
        { hour: 6, label: 'Temperature deviation alarm', completed: true, notes: 'Water chiller solenoid inspected' }
      ],
      historyReadings: [
        { hour: 0, time: '02:00', tempC: 32.0, ph: 6.9, od600: 0.05, doPercent: 92.0 },
        { hour: 4, time: '06:00', tempC: 33.1, ph: 6.6, od600: 0.45, doPercent: 50.0 },
        { hour: 8, time: '10:00', tempC: 34.2, ph: 6.4, od600: 0.95, doPercent: 28.0 }
      ]
    },
    {
      id: 'run-03',
      code: 'RUN-STANDBY',
      equipmentId: 'eq-03',
      equipmentName: 'Fermenter 03 (500 L Pilot Bioreactor)',
      microorganism: 'Standby / Sterilized',
      protocol: 'SOP-CIP-002 Steam In Place',
      medium: 'Empty / Ready for Media Charge',
      volumeLiters: 500,
      startTime: '-',
      expectedCompletion: '-',
      status: 'available',
      statusReason: 'SIP completed at 121°C, vessel ready for scale-up transfer',
      dataSource: 'Manual verified',
      currentReadings: {
        tempC: 25.0,
        ph: 7.0,
        od600: 0.0,
        doPercent: 100.0,
        aerationVvm: 0.0,
        agitationRpm: 0
      },
      timelineMilestones: [],
      historyReadings: []
    }
  ],
  equipment: [
    { id: 'eq-01', code: 'EQ-FERM-01', name: 'Fermenter 01 (100 L Glass/SS)', type: 'Bioreactor', status: 'normal', location: 'Upstream Pilot Bay A' },
    { id: 'eq-02', code: 'EQ-FERM-02', name: 'Fermenter 02 (100 L SS316L)', type: 'Bioreactor', status: 'attention', location: 'Upstream Pilot Bay B' },
    { id: 'eq-03', code: 'EQ-FERM-03', name: 'Fermenter 03 (500 L Industrial Pilot)', type: 'Bioreactor', status: 'available', location: 'Scale-Up Hall 1' },
    { id: 'eq-04', code: 'EQ-SPEC-01', name: 'UV-Vis Spectrophotometer UV-1900i', type: 'Analytical', status: 'normal', location: 'Central QC Bench' },
    { id: 'eq-05', code: 'EQ-HPLC-01', name: 'HPLC Prominence Diode Array', type: 'Analytical', status: 'normal', location: 'Chromatography Room' }
  ],
  tasks: [
    {
      id: 'task-1',
      name: 'Check Bacillus OD600 measurement',
      projectId: 'proj-1',
      assignee: 'Dr. Ragil Prasetyo',
      priority: 'High',
      dueDate: '2026-10-06',
      dueTime: '10:00',
      status: 'waiting',
      acceptanceCriteria: 'Sample from Fermenter 01 septum, dilute 1:10 with saline, verify OD600 spectrophotometer absorbance.'
    },
    {
      id: 'task-2',
      name: 'Inspect Fermenter 02 cooling chiller solenoid',
      projectId: 'proj-1',
      assignee: 'Budi Santoso',
      priority: 'High',
      dueDate: '2026-10-06',
      dueTime: '11:30',
      status: 'in_progress',
      acceptanceCriteria: 'Reset 4-20mA chiller bypass valve and restore broth temperature to 32.0 ± 0.5°C.'
    },
    {
      id: 'task-3',
      name: 'Review microbial strain bank fermentation result',
      projectId: 'proj-2',
      assignee: 'Dr. Ragil Prasetyo',
      priority: 'Medium',
      dueDate: '2026-10-06',
      dueTime: '13:00',
      status: 'todo',
      acceptanceCriteria: 'Examine cryo-recovery viability graphs and approve inclusion into institutional registry.'
    },
    {
      id: 'task-4',
      name: 'Approve next experimental design: Enzymatic Hydrolysis',
      projectId: 'proj-3',
      assignee: 'Dr. Ragil Prasetyo',
      priority: 'High',
      dueDate: '2026-10-06',
      dueTime: '15:00',
      status: 'todo',
      acceptanceCriteria: 'Confirm substrate mass balance and HPLC calibration standards before ordering enzymes.'
    }
  ],
  researchMemory: [
    {
      id: 'mem-001',
      category: 'WHAT_WE_KNOW',
      title: 'Bacillus Subtilis C:N Ratio Requirement',
      content: 'Bacillus subtilis growth kinetics require an optimal carbon-to-nitrogen (C:N) ratio between 8:1 and 10:1. Excess free sugars without adequate amino nitrogen trigger overflow acid production, lowering pH and inhibiting sporulation.',
      date: '2026-09-12',
      projectId: 'proj-1',
      confidence: 'High'
    },
    {
      id: 'mem-002',
      category: 'WHAT_WE_DECIDED',
      title: 'Adoption of Dissolved Oxygen Cascade Control',
      content: 'Decision #015: Set DO cascade to trigger agitator speed increase (200 -> 350 rpm) before increasing mass airflow (vvm) to prevent shear stress on filamentous transitions.',
      date: '2026-09-28',
      projectId: 'proj-1',
      confidence: 'Confirmed'
    },
    {
      id: 'mem-003',
      category: 'WHAT_WE_TESTED',
      title: 'Soy Peptone vs Yeast Extract Hydrolysate',
      content: 'Evaluated 3 concentrations of soy peptone (0.5%, 1.0%, 1.5%) against standard yeast extract. Soy peptone showed 18% slower initial solubilization.',
      date: '2026-09-15',
      projectId: 'proj-1',
      confidence: 'High'
    },
    {
      id: 'mem-004',
      category: 'WHAT_WORKED',
      title: 'Fed-Batch Glucose Pulse at Hour 14',
      content: 'Adding a 20 g/L sterile glucose pulse once DO spiked sharply at hour 14 extended linear growth by 6 hours, pushing final cell density from OD 1.15 to 1.48.',
      date: '2026-09-22',
      projectId: 'proj-1',
      confidence: 'High'
    },
    {
      id: 'mem-005',
      category: 'WHAT_FAILED',
      title: 'Unbuffered Ammonium Sulfate as Sole Nitrogen Source',
      content: 'Using (NH4)2SO4 without calcium carbonate or automated base titration caused severe pH crash from 6.8 to 4.9 within 9 hours, resulting in complete cell lysis.',
      date: '2026-08-30',
      projectId: 'proj-1',
      confidence: 'High'
    },
    {
      id: 'mem-006',
      category: 'WHAT_CHANGED',
      title: 'Inoculum Preparation Age Standardized to 12 Hours',
      content: 'Shifted standard inoculum preparation from 18-hour stationary culture to 12-hour mid-log culture. Reduced fermenter lag phase by 2.5 hours consistently.',
      date: '2026-09-05',
      projectId: 'proj-1',
      confidence: 'Confirmed'
    },
    {
      id: 'mem-007',
      category: 'WHAT_REMAINS_UNKNOWN',
      title: 'Surfactin Surfactant Foaming Impact on Oxygen Transfer at 500 L',
      content: 'Does high surfactin secretion by Bacillus BD-018 create excessive bubble retention and foaming at 500 L scale that cannot be controlled by 0.1% silicone antifoam?',
      date: '2026-10-01',
      projectId: 'proj-1',
      confidence: 'Low'
    },
    {
      id: 'mem-008',
      category: 'WHAT_SHOULD_BE_TESTED_NEXT',
      title: 'Evaluate Dual-Impeller Rushton + Marine Hydrofoil on Fermenter 03',
      content: 'Prioritize testing a bottom Rushton turbine for gas dispersion coupled with an upper marine hydrofoil for axial liquid blending in Fermenter 03 before pilot scale-up.',
      date: '2026-10-04',
      projectId: 'proj-1',
      confidence: 'Medium'
    }
  ],
  decisions: [
    {
      id: 'dec-015',
      code: 'DEC-2026-015',
      decision: 'Set Operating DO Cascade Setpoint to 35%',
      rationale: 'Kinetics data showed cellular sporulation genes are repressed when dissolved oxygen falls below 25%, while DO > 50% yields diminishing metabolic return.',
      status: 'Approved & Implemented',
      date: '2026-09-28',
      projectId: 'proj-1'
    },
    {
      id: 'dec-016',
      code: 'DEC-2026-016',
      decision: 'Standardize Cryo-Preservation Media to 15% Glycerol in PBS',
      rationale: 'Achieved 98.4% viability recovery and zero morphology drift compared to DMSO.',
      status: 'Approved & Implemented',
      date: '2026-10-02',
      projectId: 'proj-2'
    }
  ],
  researchQuestions: [
    {
      id: 'rq-001',
      code: 'RQ-001',
      question: 'Bagaimana mencapai target densitas produksi fermentasi Bacillus (OD600 > 1.2, 10^9 CFU/ml) dalam tempo 36 jam?',
      status: 'INVESTIGATING',
      priority: 'High',
      projectId: 'proj-1',
      projectName: 'BlueDragon Upgrade',
      relatedExperiments: ['EXP-BD-023', 'EXP-021', 'EXP-024'],
      evidence: 'Media yang diperkaya dengan 3% tetes tebu + 0.5% yeast extract mencapai OD 1.14 pada jam ke-24, namun oksigen terlarut menjadi limiting factor di atas OD 0.9.',
      currentHypothesis: 'Pengayaan media mengendalikan lag phase awal, namun aerasi kaskade bertingkat wajib diterapkan untuk mencegah kelaparan oksigen pada fase eksponensial.',
      hypothesis: 'Pengayaan media mengendalikan lag phase awal, namun aerasi kaskade bertingkat wajib diterapkan untuk mencegah kelaparan oksigen pada fase eksponensial.',
      nextRecommendedExperiment: 'Uji faktorial 2-faktor membandingkan konsentrasi peptone vs setpoint DO kaskade >35%.',
      createdDate: '2026-09-20'
    },
    {
      id: 'rq-002',
      code: 'RQ-002',
      question: 'Bagaimana mitigasi foaming ekstrem akibat biosurfaktan surfactin pada bioreaktor skala 500 L?',
      status: 'OPEN',
      priority: 'Medium',
      projectId: 'proj-1',
      projectName: 'BlueDragon Upgrade',
      relatedExperiments: ['EXP-BD-023'],
      evidence: 'Pengamatan batch pilot menunjukkan busa tebal di jam ke-16 menghambat kaskade transfer oksigen jika hanya menggunakan antifoam silikon statis.',
      currentHypothesis: 'Mechanical foam breaker dikombinasikan dengan natural polyglycerol antifoam lebih efektif dan tidak meracuni viabilitas spora dibanding silikon dosis tinggi.',
      hypothesis: 'Mechanical foam breaker dikombinasikan dengan natural polyglycerol antifoam lebih efektif dan tidak meracuni viabilitas spora dibanding silikon dosis tinggi.',
      nextRecommendedExperiment: 'Titirasi antifoam preventif 0.05% saat OD600 melewati 0.8 pada bejana 10 L.',
      createdDate: '2026-10-01'
    },
    {
      id: 'rq-003',
      code: 'RQ-003',
      question: 'Apakah hidrolisat oligosakarida rumput laut dapat menggantikan mikronutrien sintetis pada media bioprotektan?',
      status: 'OPEN',
      priority: 'Medium',
      projectId: 'proj-4',
      projectName: 'Bio Shield',
      relatedExperiments: ['EXP-015'],
      evidence: 'Hidrolisat Sargassum mengandung 19% oligosakarida serta kaya kalium, mannitol, dan trace mineral boron terlarut.',
      currentHypothesis: 'Penambahan 5% hidrolisat rumput laut menyediakan karbon bioavailable dan mempercepat perkecambahan spora hingga 24 jam lebih awal.',
      hypothesis: 'Penambahan 5% hidrolisat rumput laut menyediakan karbon bioavailable dan mempercepat perkecambahan spora hingga 24 jam lebih awal.',
      nextRecommendedExperiment: 'Skrining pertumbuhan radial pada cawan agar bersuplemen 1%, 3%, 5% hidrolisat rumput laut.',
      createdDate: '2026-10-03'
    }
  ],
  knowledgeDocs: [
    {
      id: 'doc-001',
      title: 'SOP-FERM-001 v2.2: Standard Operating Procedure for Bacillus Fermentation',
      category: 'Standard Operating Procedure (SOP)',
      author: 'Dr. Ragil Prasetyo',
      date: '2026-09-29'
    },
    {
      id: 'doc-002',
      title: 'Metabolic Flux Analysis of Bacillus Subtilis in High-Density Fermentation',
      category: 'Research Paper',
      author: 'Journal of Industrial Microbiology & Biotechnology',
      date: '2025-11-14'
    }
  ],
  importedSources: [
    {
      id: 'imp-chatgpt-01',
      platform: 'ChatGPT',
      title: 'Optimization of Bacillus Fermentation Kinetics & Substrate Titration',
      date: '2026-09-30',
      author: 'Dr. Ragil Prasetyo',
      projectId: 'proj-1',
      projectName: 'BlueDragon Upgrade',
      status: 'APPROVED',
      shareUrl: 'https://chatgpt.com/share/6702a4fc-e688-8002-8a90-84dc248d79cf',
      rawText: 'User: Bagaimana cara mempercepat pertumbuhan Bacillus dari 7 hari menjadi 3 hari dalam bioreaktor?\nChatGPT: Untuk mempercepat pertumbuhan Bacillus subtilis, fokuskan pada fase eksponensial dengan substitusi cane molasses 3% + yeast extract 0.5% dan DO >35%.',
      dialogue: [
        {
          id: 'msg-101',
          role: 'user',
          text: 'Bagaimana cara mempercepat pertumbuhan Bacillus subtilis dari siklus standar 7 hari menjadi 3 hari dalam bioreaktor 100 L?',
          timestamp: '2026-09-30 09:12'
        },
        {
          id: 'msg-102',
          role: 'assistant',
          text: 'Untuk memangkas siklus fermentasi Bacillus subtilis secara aman dari 7 hari menjadi 36-48 jam tanpa mengorbankan viabilitas spora akhir, fokuskan intervensi pada 3 pilar fase eksponensial:\n\n1. **Substitusi & Pengayaan Substrat Cepat**:\n   • Gantikan sebagian glukosa murni dengan cane molasses 3% w/v + ekstrak ragi (yeast extract) 0.5%. Kombinasi ini memasok asam amino esensial dan trace mineral yang langsung memotong lag phase awal dari 6 jam menjadi <2.5 jam.\n\n2. **Kaskade Aerasi & Dissolved Oxygen (DO)**:\n   • Oksigen terlarut adalah bottleneck mutlak saat OD600 melewati 0.8. Pertahankan setpoint DO kaskade >35% dengan otomatisasi kenaikan agitasi (250 → 450 rpm) dan laju aerasi (1.0 → 1.5 vvm).\n   • Jangan biarkan DO turun ke bawah 20%, karena Bacillus akan beralih ke fermentasi overflow asam organik yang merusak pH.\n\n3. **Inokulum Kultur Benih Berkualitas Tinggi**:\n   • Naikkan rasio inokulasi dari 0.5% menjadi 2.0% v/v menggunakan kultur cair mid-log umur 8-10 jam (OD 0.8-1.0).\n\n**Rekomendasi Eksperimen**: Lakukan A/B test factorial membandingkan pengayaan media vs aerasi kaskade sebelum memutuskan parameter final untuk bejana 500 L.',
          timestamp: '2026-09-30 09:13'
        },
        {
          id: 'msg-103',
          role: 'user',
          text: 'Apakah aman jika saya menaikkan konsentrasi molasses langsung ke 5% atau 6% agar sel tidak kehabisan karbon di tengah jalan?',
          timestamp: '2026-09-30 09:16'
        },
        {
          id: 'msg-104',
          role: 'assistant',
          text: '⚠️ **Sangat tidak disarankan.** Konsentrasi molasses > 4% w/v memicu dua kendala bio-proses serius:\n\n1. **Tekanan Osmotik (Osmotic Shock)**: Kadar sukrosa dan abu mineral yang terlalu pekat menekan laju pertumbuhan sel hingga 30-40% serta memicu autolisis sel.\n2. **Penurunan Nilai kLa (Transfer Oksigen)**: Viskositas cairan brot menjadi kental, membuat gelembung udara sulit terdispersi dan memperparah kelaparan oksigen.\n\n**Solusi Terbaik**: Mulai dengan 3% molasses di awal, lalu berikan fed-batch pulse 1.5% molasses tambahan pada jam ke-14 saat DO melonjak tajam.',
          timestamp: '2026-09-30 09:18'
        }
      ],
      keyInsights: [
        'Molasses 3% + yeast extract 0.5% memotong lag phase dari 6 jam ke <2.5 jam',
        'Konsentrasi molasses >4% memicu osmotic shock dan penurunan transfer oksigen (kLa)',
        'DO cascade >35% wajib dijaga pada fase log untuk mencegah acidification overflow',
        'Kultur inokulum benih 2.0% v/v umur 8-10 jam memberikan akselerasi batch optimum'
      ],
      extracted: {
        topics: ['Bacillus subtilis acceleration', 'Media composition', 'DO cascade control', 'Inoculum density'],
        findings: [
          'Molasses 3% + yeast extract 0.5% accelerates log phase initiation',
          'Inoculum density 2.0% shortens lag time significantly',
          'DO maintained >30% prevents organic acid accumulation'
        ],
        decisions: ['Adopt 2.0% seed culture as standard inoculation density'],
        potentialExperiments: [
          {
            title: 'Compare Media Optimization vs Aeration Optimization',
            control: 'Standard medium + 0.8 vvm',
            treatments: ['Optimized medium + 0.8 vvm', 'Standard medium + 1.2 vvm cascade', 'Dual optimized'],
            measurements: ['OD600', 'pH', 'DO %', 'CFU/ml']
          }
        ],
        tasks: [
          { title: 'Screen cane molasses batch purity', priority: 'Medium', due: '2026-10-08' },
          { title: 'Calibrate optical DO sensor probe', priority: 'High', due: '2026-10-05' }
        ],
        unresolvedQuestions: [
          'Apakah molase dengan kadar sukrosa fluktuatif akan mempengaruhi konsistensi batch?',
          'Berapa batas viskositas media sebelum transfer oksigen terhambat?'
        ]
      }
    },
    {
      id: 'imp-chatgpt-02',
      platform: 'ChatGPT',
      title: 'Strategi Mitigasi Foaming Biosurfaktan Surfactin pada Skala Bioreaktor 500 L',
      date: '2026-10-02',
      author: 'Dr. Ragil Prasetyo',
      projectId: 'proj-1',
      projectName: 'BlueDragon Upgrade',
      status: 'APPROVED',
      shareUrl: 'https://chatgpt.com/share/6703bc10-f124-8002-9b21-72ef451a99ef',
      rawText: 'User: Bagaimana mengatasi busa hebat akibat produksi surfactin oleh Bacillus pada fermenter 500L?\nChatGPT: Pasang mechanical foam breaker di headspace bioreaktor dan gunakan polyglycerol ester 0.05% via sensor busa konduktif.',
      dialogue: [
        {
          id: 'msg-201',
          role: 'user',
          text: 'Bagaimana mengatasi busa hebat akibat produksi biosurfaktan surfactin oleh Bacillus pada fermenter pilot 500 L tanpa merusak viabilitas spora akhir?',
          timestamp: '2026-10-02 14:05'
        },
        {
          id: 'msg-202',
          role: 'assistant',
          text: 'Sekresi surfactin oleh strain *Bacillus subtilis* menurunkan tegangan permukaan cairan brot secara ekstrem antara jam ke-14 s/d 22, memicu luapan busa tebal ke exhaust line.\n\nBerikut rekomendasi pengendalian terintegrasi:\n\n1. **Pasang Mechanical Foam Breaker di Headspace**:\n   • Gunakan impeler piringan pemecah busa mekanis di poros atas agitator Fermenter 03. Putaran mekanis memecah busa kembali menjadi cairan tanpa menambahkan beban kimiawi pada sel.\n\n2. **Batasi Antifoam Silikon Dosis Tinggi**:\n   • Pemberian emulsi silikon >0.2% v/v akan menyelimuti permukaan sel mikroba dan menghambat perpindahan massa oksigen (kLa turun hingga 45%).\n   • Beralihlah ke **Polyglycerol Fatty Acid Ester (PGFE)** food-grade dengan dosis mikro 0.03% - 0.05%.\n\n3. **Sensor Busa Konduktif Otomatis**:\n   • Hubungkan injeksi antifoam ke probe sensor level busa otomatis untuk mencegah akumulasi antifoam yang tidak perlu.',
          timestamp: '2026-10-02 14:07'
        }
      ],
      keyInsights: [
        'Mechanical foam breaker di headspace 500 L mengeliminasi 70% ketergantungan antifoam kimiawi',
        'Silikon dosis >0.2% v/v merusak efisiensi transfer oksigen respirasi sel',
        'Gunakan ester asam lemak poligiserol (PGFE 0.03-0.05%) sebagai pengganti silikon konvensional'
      ],
      extracted: {
        topics: ['Surfactin biosurfactant', 'Headspace mechanical foam breaker', 'Polyglycerol ester antifoam'],
        findings: [
          'Excess silicone antifoam impairs cellular oxygen uptake rate',
          'Mechanical foam breaker is critical for 500 L pilot vessel operation'
        ],
        decisions: ['Prioritize mechanical foam breaker installation on Fermenter 03'],
        potentialExperiments: [
          {
            title: 'Mechanical Foam Breaker vs Chemical Antifoam Titration',
            control: 'Standard 0.1% silicone antifoam dosing',
            treatments: ['Mechanical foam breaker alone', 'PGFE 0.03% + mechanical foam breaker'],
            measurements: ['Tinggi busa (cm)', 'Koefisien kLa', 'Viabilitas spora (CFU/ml)']
          }
        ],
        tasks: [
          { title: 'Inspect Fermenter 03 upper agitator shaft mounting', priority: 'High', due: '2026-10-08' }
        ],
        unresolvedQuestions: [
          'Apakah putaran mechanical foam breaker 600 rpm menimbulkan shear stress pada spora muda?'
        ]
      }
    }
  ],
  conversations: [
    {
      id: 'conv-01',
      title: 'Optimasi Fermentasi Bacillus (Media vs Aerasi)',
      projectId: 'proj-1',
      updatedAt: '2026-10-06 10:15',
      messages: [
        {
          id: 'msg-1',
          sender: 'user',
          text: 'Menurutmu untuk mempercepat fermentasi Bacillus, lebih baik optimasi media atau aerasi?',
          timestamp: '10/06 10:12'
        },
        {
          id: 'msg-2',
          sender: 'assistant',
          characterId: 'aria',
          text: 'Berdasarkan data eksperimen sebelumnya (EXP-BD-021) dan kinetika pertumbuhan Bacillus subtilis, optimasi media (khususnya penambahan nitrogen organik terlarut / yeast extract) sebaiknya diuji terlebih dahulu.\n\nAlasan ilmiah:\n1. Ketersediaan asam amino bebas menentukan durasi lag-phase (data historis membuktikan lag phase terpangkas 2.5 jam saat rasio C:N dijaga 8:1 - 10:1).\n2. Aerasi berlebih tanpa nutrisi cukup justru meningkatkan tegangan geser (shear stress) dan memicu foaming berlebih dari surfaktan.\n\nSaya menyarankan pengujian A/B terkontrol (Control: Protokol standar, Treatment A: Media optimal, Treatment B: Aerasi 1.5 vvm).',
          timestamp: '10/06 10:14'
        }
      ]
    }
  ],
  userProfile: {
    name: 'Dr. Ragil Prasetyo',
    role: 'R&D Lead Researcher & Bioprocess Manager',
    email: 'ragil.prasetyo@biotech-research.io',
    organization: 'PT Nusantara Bio-Innovation Laboratory',
    initials: 'RP',
    avatarColor: 'bg-red-600'
  },
  labSettings: {
    dataSourceMode: 'thingsboard',
    tempAlarmThreshold: 38.0,
    minDoThreshold: 20.0,
    odReminderHours: 4,
    autoLogIntervalMin: 15,
    thingsboard: {
      serverUrl: 'https://thingsboard.cloud',
      deviceToken: 'TB_FERM01_PROD_TOKEN_88X',
      deviceId: 'DEV-FERMENTER-01',
      deviceName: 'Bacillus Bioreactor Unit 01',
      protocol: 'http',
      pollIntervalSec: 10,
      isConnected: true,
      lastSyncTime: 'Baru saja (Live SQLite Connected)',
      telemetryKeys: {
        temperature: 'temperature',
        do: 'do_percent',
        od600: 'od600',
        ph: 'ph',
        rpm: 'agitator_rpm'
      },
      devices: [
        {
          id: 'tb-dev-1',
          fermenterId: 'fermenter-01',
          name: 'Fermenter 01 (100 L Bacillus Seed)',
          token: 'TB_FERM01_PROD_TOKEN_88X',
          active: true,
          status: 'online',
          lastReading: {
            temperature: 37.2,
            do: 42.5,
            od600: 1.14,
            ph: 6.8,
            rpm: 250,
            timestamp: 'Baru saja'
          }
        },
        {
          id: 'tb-dev-2',
          fermenterId: 'fermenter-02',
          name: 'Fermenter 02 (100 L Bacillus Production)',
          token: 'TB_FERM02_ALERT_TOKEN_99Y',
          active: true,
          status: 'online',
          lastReading: {
            temperature: 34.2,
            do: 28.0,
            od600: 0.95,
            ph: 6.4,
            rpm: 300,
            timestamp: '1 menit lalu'
          }
        },
        {
          id: 'tb-dev-3',
          fermenterId: 'fermenter-03',
          name: 'Fermenter 03 (500 L Scale-Up Unit)',
          token: 'TB_FERM03_STANDBY_TOKEN_11Z',
          active: false,
          status: 'idle',
          lastReading: {
            temperature: 25.0,
            do: 98.0,
            od600: 0.05,
            ph: 7.0,
            rpm: 0,
            timestamp: '15 menit lalu'
          }
        }
      ]
    }
  },
  brainSettings: {
    strictEpistemicSeparation: true,
    minConfidenceFilter: 'All',
    enableDebateModeByDefault: false,
    voiceAudioEnabled: true,
    proactiveBubbleEnabled: true
  },
  selectedCharacterId: 'aria'
};
